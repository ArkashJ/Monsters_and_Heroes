package main.Teams;

public class TeamMonsters extends Team {
    public TeamMonsters(int teamSize) {
        super("Monsters", teamSize);
    }
}
