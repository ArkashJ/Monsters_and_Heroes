package main.Characters.Monsters;

public interface IMonsters {
    double getBaseDamage();
    double getDefenseValue();
    double getDodge();
    double getHP();
    void setBaseDamage(double baseDamage);
    void setDefenceValue(double defenceValue);
    void setDodgeAgility(double dodgeAgility);
}
