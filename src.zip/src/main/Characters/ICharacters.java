package main.Characters;

public interface ICharacters {
    String getName();
     int getLevel();
     double getHP();
    void printStats();

    void setHP(double HP);
}
