package main.Positions;

public interface IPositions {
    int getX_pos();
    int getY_pos();
    void setPos(int x_pos, int y_pos);
    int getPreviousX_pos();
    int getPreviousY_pos();
}
