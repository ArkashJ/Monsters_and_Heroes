SPELLS
The stats for this armor are as follows:
Name: Flame_Tornado  |  Level: 4  |  HP: 700  |  MP: 850.000  |  MP: 300  |  
The stats for this armor are as follows:
Name: Breath_of_Fire  |  Level: 1  |  HP: 350  |  MP: 450.000  |  MP: 100  |  
The stats for this armor are as follows:
Name: Heat_Wave  |  Level: 2  |  HP: 450  |  MP: 600.000  |  MP: 150  |  
The stats for this armor are as follows:
Name: Lava_Comet  |  Level: 7  |  HP: 800  |  MP: 1,000.000  |  MP: 550  |  
The stats for this armor are as follows:
Name: Hell_Storm  |  Level: 3  |  HP: 600  |  MP: 950.000  |  MP: 600  |
--------------------
The stats for this armor are as follows:
Name: Snow_Cannon  |  Level: 2  |  HP: 500  |  MP: 650.000  |  MP: 250  |  
The stats for this armor are as follows:
Name: Ice_Blade  |  Level: 1  |  HP: 250  |  MP: 450.000  |  MP: 100  |  
The stats for this armor are as follows:
Name: Frost_Blizzard  |  Level: 5  |  HP: 750  |  MP: 850.000  |  MP: 350  |  
The stats for this armor are as follows:
Name: Arctic_Storm  |  Level: 6  |  HP: 700  |  MP: 800.000  |  MP: 300  |
--------------------
The stats for this armor are as follows:
Name: Lightning_Dagger  |  Level: 1  |  HP: 400  |  MP: 500.000  |  MP: 150  |  
The stats for this armor are as follows:
Name: Thunder_Blast  |  Level: 4  |  HP: 750  |  MP: 950.000  |  MP: 400  |  
The stats for this armor are as follows:
Name: Electric_Arrows  |  Level: 5  |  HP: 550  |  MP: 650.000  |  MP: 200  |  
The stats for this armor are as follows:
Name: Spark_Needles  |  Level: 2  |  HP: 500  |  MP: 600.000  |  MP: 200  |
--------------------


HEROES:

The stats for this player are as follows:
Name: Parzival  |  Level: 7  |  HP: 700.000  |  MP: 300.000  |  Dexterity: 700.000  |  Agility: 650.000  |  Strength: 750.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Sehanine_Moonbow  |  Level: 7  |  HP: 700.000  |  MP: 300.000  |  Dexterity: 700.000  |  Agility: 700.000  |  Strength: 750.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Skoraeus_Stonebones  |  Level: 4  |  HP: 400.000  |  MP: 250.000  |  Dexterity: 350.000  |  Agility: 600.000  |  Strength: 650.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Garl_Glittergold  |  Level: 5  |  HP: 500.000  |  MP: 100.000  |  Dexterity: 400.000  |  Agility: 500.000  |  Strength: 600.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Amaryllis_Astra  |  Level: 5  |  HP: 500.000  |  MP: 500.000  |  Dexterity: 500.000  |  Agility: 500.000  |  Strength: 500.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Caliber_Heist  |  Level: 8  |  HP: 800.000  |  MP: 400.000  |  Dexterity: 400.000  |  Agility: 400.000  |  Strength: 400.000  |  Gold: 2500  |  
The inventory currently is: --------------------
The stats for this player are as follows:
Name: Rillifane_Rallathil  |  Level: 9  |  HP: 900.000  |  MP: 1,300.000  |  Dexterity: 500.000  |  Agility: 450.000  |  Strength: 750.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Segojan_Earthcaller  |  Level: 5  |  HP: 500.000  |  MP: 900.000  |  Dexterity: 650.000  |  Agility: 500.000  |  Strength: 800.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Reign_Havoc  |  Level: 8  |  HP: 800.000  |  MP: 800.000  |  Dexterity: 800.000  |  Agility: 800.000  |  Strength: 800.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Reverie_Ashels  |  Level: 7  |  HP: 700.000  |  MP: 900.000  |  Dexterity: 400.000  |  Agility: 700.000  |  Strength: 800.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Kalabar  |  Level: 6  |  HP: 600.000  |  MP: 800.000  |  Dexterity: 600.000  |  Agility: 400.000  |  Strength: 850.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Skye_Soar  |  Level: 5  |  HP: 500.000  |  MP: 1,000.000  |  Dexterity: 500.000  |  Agility: 400.000  |  Strength: 700.000  |  Gold: 2500  |  
The inventory currently is: --------------------
The stats for this player are as follows:
Name: Gaerdal_Ironhand  |  Level: 7  |  HP: 700.000  |  MP: 100.000  |  Dexterity: 600.000  |  Agility: 500.000  |  Strength: 700.000  |  Gold: 1354  |  
The inventory currently is: The stats for this player are as follows:
Name: Sehanine_Monnbow  |  Level: 8  |  HP: 800.000  |  MP: 600.000  |  Dexterity: 500.000  |  Agility: 800.000  |  Strength: 700.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Muamman_Duathall  |  Level: 6  |  HP: 600.000  |  MP: 300.000  |  Dexterity: 750.000  |  Agility: 500.000  |  Strength: 900.000  |  Gold: 2546  |  
The inventory currently is: The stats for this player are as follows:
Name: Flandal_Steelskin  |  Level: 7  |  HP: 700.000  |  MP: 200.000  |  Dexterity: 700.000  |  Agility: 650.000  |  Strength: 750.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Undefeated_Yoj  |  Level: 7  |  HP: 700.000  |  MP: 400.000  |  Dexterity: 700.000  |  Agility: 400.000  |  Strength: 800.000  |  Gold: 2500  |  
The inventory currently is: The stats for this player are as follows:
Name: Eunoia_Cyn  |  Level: 6  |  HP: 600.000  |  MP: 400.000  |  Dexterity: 600.000  |  Agility: 800.000  |  Strength: 700.000  |  Gold: 2500  |  
The inventory currently is: --------------------


MONSTERS:
The stats for this monster are as follows:
Name: Cyrrollalee  |  Level: 7  |  HP: 7,500.000  |  Base-Damage: 700.000  |  Defence-Value: 800.000  |  Dodge-Agility: 75.000  |  
The stats for this monster are as follows:
Name: Brandobaris  |  Level: 3  |  HP: 3,000.000  |  Base-Damage: 350.000  |  Defence-Value: 450.000  |  Dodge-Agility: 30.000  |  
The stats for this monster are as follows:
Name: BigBad-Wolf  |  Level: 1  |  HP: 1,500.000  |  Base-Damage: 150.000  |  Defence-Value: 250.000  |  Dodge-Agility: 15.000  |  
The stats for this monster are as follows:
Name: WickedWitch  |  Level: 2  |  HP: 2,500.000  |  Base-Damage: 250.000  |  Defence-Value: 350.000  |  Dodge-Agility: 25.000  |  
The stats for this monster are as follows:
Name: Aasterinian  |  Level: 4  |  HP: 4,500.000  |  Base-Damage: 400.000  |  Defence-Value: 500.000  |  Dodge-Agility: 45.000  |  
The stats for this monster are as follows:
Name: Chronepsish  |  Level: 6  |  HP: 6,000.000  |  Base-Damage: 650.000  |  Defence-Value: 750.000  |  Dodge-Agility: 60.000  |  
The stats for this monster are as follows:
Name: Kiaransalee  |  Level: 8  |  HP: 8,500.000  |  Base-Damage: 850.000  |  Defence-Value: 950.000  |  Dodge-Agility: 85.000  |  
The stats for this monster are as follows:
Name: St-Shargaas  |  Level: 5  |  HP: 5,500.000  |  Base-Damage: 550.000  |  Defence-Value: 650.000  |  Dodge-Agility: 55.000  |  
The stats for this monster are as follows:
Name: Merrshaullk  |  Level: 10  |  HP: 5,500.000  |  Base-Damage: 1,000.000  |  Defence-Value: 900.000  |  Dodge-Agility: 55.000  |  
The stats for this monster are as follows:
Name: St-Yeenoghu  |  Level: 9  |  HP: 9,000.000  |  Base-Damage: 950.000  |  Defence-Value: 850.000  |  Dodge-Agility: 90.000  |  
The stats for this monster are as follows:
Name: DocOck  |  Level: 6  |  HP: 5,500.000  |  Base-Damage: 600.000  |  Defence-Value: 600.000  |  Dodge-Agility: 55.000  |  
The stats for this monster are as follows:
Name: Exodia  |  Level: 10  |  HP: 5,000.000  |  Base-Damage: 1,000.000  |  Defence-Value: 1,000.000  |  Dodge-Agility: 50.000  |
--------------------
The stats for this monster are as follows:
Name: Andrealphus  |  Level: 2  |  HP: 4,000.000  |  Base-Damage: 600.000  |  Defence-Value: 500.000  |  Dodge-Agility: 40.000  |  
The stats for this monster are as follows:
Name: Blinky  |  Level: 1  |  HP: 3,500.000  |  Base-Damage: 450.000  |  Defence-Value: 350.000  |  Dodge-Agility: 35.000  |  
The stats for this monster are as follows:
Name: Andromalius  |  Level: 3  |  HP: 2,500.000  |  Base-Damage: 550.000  |  Defence-Value: 450.000  |  Dodge-Agility: 25.000  |  
The stats for this monster are as follows:
Name: Chiang-shih  |  Level: 4  |  HP: 4,000.000  |  Base-Damage: 700.000  |  Defence-Value: 600.000  |  Dodge-Agility: 40.000  |  
The stats for this monster are as follows:
Name: FallenAngel  |  Level: 5  |  HP: 5,000.000  |  Base-Damage: 800.000  |  Defence-Value: 700.000  |  Dodge-Agility: 50.000  |  
The stats for this monster are as follows:
Name: Ereshkigall  |  Level: 6  |  HP: 3,500.000  |  Base-Damage: 950.000  |  Defence-Value: 450.000  |  Dodge-Agility: 35.000  |  
The stats for this monster are as follows:
Name: Melchiresas  |  Level: 7  |  HP: 7,500.000  |  Base-Damage: 350.000  |  Defence-Value: 150.000  |  Dodge-Agility: 75.000  |  
The stats for this monster are as follows:
Name: Jormunngand  |  Level: 8  |  HP: 2,000.000  |  Base-Damage: 600.000  |  Defence-Value: 900.000  |  Dodge-Agility: 20.000  |  
The stats for this monster are as follows:
Name: Rakkshasass  |  Level: 9  |  HP: 3,500.000  |  Base-Damage: 550.000  |  Defence-Value: 600.000  |  Dodge-Agility: 35.000  |  
The stats for this monster are as follows:
Name: Taltecuhtli  |  Level: 10  |  HP: 5,000.000  |  Base-Damage: 300.000  |  Defence-Value: 200.000  |  Dodge-Agility: 50.000  |  
The stats for this monster are as follows:
Name: Casper  |  Level: 1  |  HP: 5,000.000  |  Base-Damage: 100.000  |  Defence-Value: 100.000  |  Dodge-Agility: 50.000  |
--------------------
The stats for this monster are as follows:
Name: Desghidorrah  |  Level: 3  |  HP: 3,500.000  |  Base-Damage: 300.000  |  Defence-Value: 400.000  |  Dodge-Agility: 35.000  |  
The stats for this monster are as follows:
Name: Chrysophylax  |  Level: 2  |  HP: 2,000.000  |  Base-Damage: 200.000  |  Defence-Value: 500.000  |  Dodge-Agility: 20.000  |  
The stats for this monster are as follows:
Name: BunsenBurner  |  Level: 4  |  HP: 4,500.000  |  Base-Damage: 400.000  |  Defence-Value: 500.000  |  Dodge-Agility: 45.000  |  
The stats for this monster are as follows:
Name: Natsunomeryu  |  Level: 1  |  HP: 1,000.000  |  Base-Damage: 100.000  |  Defence-Value: 200.000  |  Dodge-Agility: 10.000  |  
The stats for this monster are as follows:
Name: TheScaleless  |  Level: 7  |  HP: 7,500.000  |  Base-Damage: 700.000  |  Defence-Value: 600.000  |  Dodge-Agility: 75.000  |  
The stats for this monster are as follows:
Name: Kas-Ethelinh  |  Level: 5  |  HP: 6,000.000  |  Base-Damage: 600.000  |  Defence-Value: 500.000  |  Dodge-Agility: 60.000  |  
The stats for this monster are as follows:
Name: Alexstraszan  |  Level: 10  |  HP: 5,500.000  |  Base-Damage: 1,000.000  |  Defence-Value: 9,000.000  |  Dodge-Agility: 55.000  |  
The stats for this monster are as follows:
Name: Phaarthurnax  |  Level: 6  |  HP: 6,000.000  |  Base-Damage: 600.000  |  Defence-Value: 700.000  |  Dodge-Agility: 60.000  |  
The stats for this monster are as follows:
Name: D-Maleficent  |  Level: 9  |  HP: 8,500.000  |  Base-Damage: 900.000  |  Defence-Value: 950.000  |  Dodge-Agility: 85.000  |  
The stats for this monster are as follows:
Name: TheWeatherbe  |  Level: 8  |  HP: 8,000.000  |  Base-Damage: 800.000  |  Defence-Value: 900.000  |  Dodge-Agility: 80.000  |  
The stats for this monster are as follows:
Name: Igneel  |  Level: 6  |  HP: 6,000.000  |  Base-Damage: 600.000  |  Defence-Value: 400.000  |  Dodge-Agility: 60.000  |  
The stats for this monster are as follows:
Name: BlueEyesWhite  |  Level: 9  |  HP: 7,500.000  |  Base-Damage: 900.000  |  Defence-Value: 600.000  |  Dodge-Agility: 75.000  |
--------------------


POTIONS
The stats for this potion are as follows:
Name: Healing_Potion  |  Level: 1  |  HP: 250  |  Effect Amount: 100  |  Property: Health
The stats for this potion are as follows:
Name: Strength_Potion  |  Level: 1  |  HP: 200  |  Effect Amount: 75  |  Property: Strength
The stats for this potion are as follows:
Name: Magic_Potion  |  Level: 2  |  HP: 350  |  Effect Amount: 100  |  Property: Mana
The stats for this potion are as follows:
Name: Luck_Elixir  |  Level: 4  |  HP: 500  |  Effect Amount: 65  |  Property: Agility
The stats for this potion are as follows:
Name: Mermaid_Tears  |  Level: 5  |  HP: 850  |  Effect Amount: 100  |  Property: Health/Mana/Strength/Agility
The stats for this potion are as follows:
Name: Ambrosia  |  Level: 8  |  HP: 1000  |  Effect Amount: 150  |  Property: All
--------------------

AMORS
The stats for this armor are as follows:
Name: Platinum_Shield  |  Level: 1  |  HP: 150  |  MP: 200.000  |  
The stats for this armor are as follows:
Name: Breastplate  |  Level: 3  |  HP: 350  |  MP: 600.000  |  
The stats for this armor are as follows:
Name: Full_Body_Armor  |  Level: 8  |  HP: 1000  |  MP: 1,100.000  |  
The stats for this armor are as follows:
Name: Wizard_Shield  |  Level: 10  |  HP: 1200  |  MP: 1,500.000  |  
The stats for this armor are as follows:
Name: Guardian_Angel  |  Level: 10  |  HP: 1000  |  MP: 1,000.000  |
--------------------

WEAPONS
The stats for this weapon are as follows:
Name: Sword  |  Level: 1  |  HP: 500  |  MP: 800.000  |  Dexterity: 1  |  
The stats for this weapon are as follows:
Name: Bow  |  Level: 2  |  HP: 300  |  MP: 500.000  |  Dexterity: 2  |  
The stats for this weapon are as follows:
Name: Scythe  |  Level: 6  |  HP: 1000  |  MP: 1,100.000  |  Dexterity: 2  |  
The stats for this weapon are as follows:
Name: Axe  |  Level: 5  |  HP: 550  |  MP: 850.000  |  Dexterity: 1  |  
The stats for this weapon are as follows:
Name: TSwords  |  Level: 8  |  HP: 1400  |  MP: 1,600.000  |  Dexterity: 2  |  
The stats for this weapon are as follows:
Name: Dagger  |  Level: 1  |  HP: 200  |  MP: 250.000  |  Dexterity: 1  |  
-----------------------------------------------------------------------------

WORLD:
x - inaccessible area
M - market
Empty cell - common space
+---+---+---+---+---+---+---+---+
| M | M |   |   |   |   | x |   |
+---+---+---+---+---+---+---+---+
| x | M |   | x |   |   | M | M |
+---+---+---+---+---+---+---+---+
|   | M | M | M |   |   |   |   |
+---+---+---+---+---+---+---+---+
| M | x | M | x | M |   |   | x |
+---+---+---+---+---+---+---+---+
|   |   | M | x |   | M | x |   |
+---+---+---+---+---+---+---+---+
| x |   |   |   | x |   | x | M |
+---+---+---+---+---+---+---+---+
| M |   |   |   |   |   | M |   |
+---+---+---+---+---+---+---+---+
| M | M | M |   |   |   |   | x |
+---+---+---+---+---+---+---+---+